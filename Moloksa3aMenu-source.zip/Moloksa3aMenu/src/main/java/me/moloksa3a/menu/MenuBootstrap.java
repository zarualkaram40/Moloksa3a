package me.moloksa3a.menu;

import io.papermc.paper.plugin.bootstrap.BootstrapContext;
import io.papermc.paper.plugin.bootstrap.PluginBootstrap;
import io.papermc.paper.plugin.lifecycle.event.types.LifecycleEvents;
import io.papermc.paper.registry.RegistryKey;
import io.papermc.paper.registry.TypedKey;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import io.papermc.paper.registry.event.RegistryEvents;
import io.papermc.paper.registry.keys.DialogKeys;
import io.papermc.paper.registry.tag.TagKey;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@SuppressWarnings("UnstableApiUsage")
public class MenuBootstrap implements PluginBootstrap {

    // Titre du menu (le nom qui apparait dans le menu pause)
    private static final String TITLE = "&6&lMoloksa3asmp";

    // { texte du bouton, commande } -- modifie ici comme tu veux
    private static final String[][] BUTTONS = {
            {"&aHomes", "homes"},
            {"&eAuction", "ah"},
            {"&aFriends", "friends"},
            {"&eOrders", "orders"},
            {"&aSell", "sell"},
            {"&ePay", "pay"},
            {"&aTeleport", "tpa"},
            {"&eStats", "stats"},
            {"&aLeaderboards", "leaderboards"},
            {"&eSettings", "settings"}
    };

    private static final TypedKey<io.papermc.paper.dialog.Dialog> KEY =
            DialogKeys.create(Key.key("moloksa3asmp", "menu"));

    @Override
    public void bootstrap(BootstrapContext context) {
        var serializer = LegacyComponentSerializer.legacyAmpersand();

        context.getLifecycleManager().registerEventHandler(RegistryEvents.DIALOG.compose().newHandler(event -> {
            List<ActionButton> actions = new ArrayList<>();
            for (String[] b : BUTTONS) {
                actions.add(ActionButton.builder(serializer.deserialize(b[0]))
                        .width(150)
                        .action(DialogAction.staticAction(ClickEvent.runCommand("/" + b[1])))
                        .build());
            }

            event.registry().register(KEY, builder -> builder
                    .base(DialogBase.builder(serializer.deserialize(TITLE))
                            .canCloseWithEscape(true)
                            .build())
                    .type(DialogType.multiAction(actions).columns(2).build()));
        }));

        // Met le dialog dans le menu pause (Echap)
        context.getLifecycleManager().registerEventHandler(
                LifecycleEvents.TAGS.postFlatten(RegistryKey.DIALOG), event ->
                        event.registrar().addToTag(
                                TagKey.create(RegistryKey.DIALOG, Key.key("pause_screen_additions")),
                                Set.of(KEY)));
    }
}
