package me.moloksa3a.menu;

import org.bukkit.plugin.java.JavaPlugin;

public class MenuPlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        getLogger().info("Moloksa3aMenu active - ouvre le menu Echap > Moloksa3asmp");
    }
}
